import express from "express";
import http from "http";
import { Server } from "socket.io";
import path from "path";
import { fileURLToPath } from "url";
import handleEvents from "./events/handleEvent.js";

// Resolve __dirname equivalent in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Pass `io` to the event handler
handleEvents(io);

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"));
});

server.listen(8000, () => {
  console.log("Server running on port 9000");
});


// client is the index.html at every connection 
// for sending emit  is used 
// for getting message on is used 
// server is io and if we emit or do anything it goes there 
// for private socket is there we emit and do anything goes to private socket 