const emitEvents = (io) => {
    // Broadcast message to all connected clients
    const broadcastMessage = (message) => {
      io.emit("message", message);
    };
  
    // Send a private message to a specific client using their socket ID
    const sendPrivateMessage = (socketId, message) => {
      const socket = io.sockets.sockets.get(socketId); // Get specific socket by ID
      if (socket) {
        socket.emit("private-message", message); // Send to the specific client
      } else {
        console.log("Client not found");
      }
    };
  
    return {
      broadcastMessage,
      sendPrivateMessage
    };
  };
  
export default emitEvents;  