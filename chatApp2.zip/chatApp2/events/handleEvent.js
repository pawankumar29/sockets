import emitEvents from "./emitEvent.js"; // Import the emit functions
const handleEvents = (io) => {
  const events = emitEvents(io); // Initialize with `io`

  io.on("connection", (socket) => {
    console.log("A user connected:", socket.id);

    // Listen for a broadcast message
    socket.on("user-message", (message) => {
      console.log("Broadcasting message:", message);
      events.broadcastMessage(message); // Send the broadcast message to all clients
    });

    // Listen for a private message
    socket.on("private-message", ({ message, socketId }) => {
      console.log(
        `Sending private message: ${message} to socket ID: ${socketId}`
      );
      events.sendPrivateMessage(socketId, message); // Send private message to the specified client
    });

    // Handle disconnect event
    socket.on("disconnect", () => {
      console.log(`Client ${socket.id} disconnected`);
    });
  });
};

export default handleEvents;
